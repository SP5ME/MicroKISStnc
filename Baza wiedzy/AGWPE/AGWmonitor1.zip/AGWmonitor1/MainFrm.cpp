// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "AGWmonitor.h"
#include "ChildFrm.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern	HMENU m_hMDIMenu;
extern  HACCEL m_hMDIAccel;

extern char IniFile[];

#define CREATETERMS WM_USER+1

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_MESSAGE(CREATETERMS,CreateTerms)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
OEMANSI=FALSE;
MonitorKind=62;
//SockFile=NULL;
AGWPESocket=NULL;
	
}

CMainFrame::~CMainFrame()
{
//		delete (ArWrite);
//	delete (ArRead);
//if (SockFile)	delete(SockFile);
if (AGWPESocket)	delete(AGWPESocket);
	OutputDebugString("DELETE MAIN\n");
//	for (int x=0;x<Ports.Num;x++) Term[x]->DestroyWindow();

}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	if (!m_wndDlgBar.Create(this, IDR_MAINFRAME, 
		CBRS_ALIGN_TOP, AFX_IDW_DIALOGBAR))
	{
		TRACE0("Failed to create dialogbar\n");
		return -1;		// fail to create
	}

	if (!m_wndReBar.Create(this) ||
		!m_wndReBar.AddBar(&m_wndToolBar) ||
		!m_wndReBar.AddBar(&m_wndDlgBar,"Fonts"))
	{
		TRACE0("Failed to create rebar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Remove this if you don't want tool tips
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY);
//create criticalsection


AGWPESocket=new AGWSocket();
AGWPESocket->SetDsktp(this);
//if (!AGWPESocket->Create(8000,SOCK_STREAM,"127.0.0.1")) OutputDebugString("Error create socket\n");
if (!AGWPESocket->Create()) OutputDebugString("Error create socket\n");

if (!AGWPESocket->Connect("44.154.129.18",8000)) 
{
	OutputDebugString("Error connecting\n");
	AfxMessageBox("Start AGW Packet Engine! ");
	return 0;
}
//SockFile=new CSocketFile(AGWPESocket);

//1.get radioports
struct HEADER Hed;
ZeroMemory(&Hed,sizeof(Hed));
Hed.port=0;
Hed.DataKind=MAKELONG('G',0);
lstrcpy((char *)Hed.callfrom,"TEST");
lstrcpy((char *)Hed.callto,"TEST");
Hed.size=0;
//SockFile->Write(&Hed,sizeof(Hed));
AGWPESocket->Send(&Hed,sizeof(Hed));
return 0;
}
//***********************************************************************
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

void CMainFrame::GetPorts(unsigned char *Str)
{
//getcolors

char *token;
token=strtok((char *)Str,";");
Ports.Num=atoi(token);
for (int x=0;x<Ports.Num;x++)
  {
  token=strtok(NULL,";");
  if (token==NULL) break;
  strcpy(Ports.Port[x],token);
  //create the windows
  }
//SendMessage(CREATETERMS);
CreateTerms();
}
//*********************************************************
void CMainFrame::CreateTerms(void)
{
char temp[255];
char MyCall[15];
COLORREF ColorWin=GetSysColor(COLOR_WINDOWTEXT	);

GetPrivateProfileString("PACKET","MYCALLCOLOR","8421376",temp,15,IniFile);
int MyColor=atoi(temp);
GetPrivateProfileString("PACKET","HEADERCOLOR","16711680",temp,15,IniFile);
int HeaderColor=atoi(temp);
GetPrivateProfileString("PACKET","MYCALL","AGW",MyCall,15,IniFile);

for (int x=0;x<Ports.Num;x++)
  {
OutputDebugString("Create Term\n");
	Term[x]=new CChildFrame;
	Term[x]->Setup(HeaderColor,ColorWin,MyColor,MyCall);
	Term[x]->Create(NULL,Ports.Port[x]);//,WS_VISIBLE|WS_CHILD|WS_OVERLAPPEDWINDOW ,rectDefault ,this);
}

// SendMessage(ClientWin,WM_MDISETMENU,(WPARAM)hmnew,NULL);
/*cm.Attach(m_hMDIMenu);
MDISetMenu(&cm,NULL);
DrawMenuBar();
*/
}
//***********************************************************
#define NOMORE2READ   0
#define MORE2READ    1
#define MORE2READHEAD 2
void CMainFrame::ReceiveData(void)
{
static char flag=NOMORE2READ;
static HEADER Header;
char *ReadedDataPtr;
//long Result;
//int Channel;
//char temp[30];
int  nLength;
//int nError;
char HeardListStr[100];
//static char szTemp[50];
int count=0;
// char temp1[100];
 char TempRead[1100];


if (flag==NOMORE2READ)
{
	ReadedDataPtr=ReadedData;
	
	HowManyCharsWait=AGWPESocket->Receive(ReadedData,1400);
	if (HowManyCharsWait==SOCKET_ERROR)  return ;
	HowManyReadSoFar=0;
 } else//we still have data in the buffer readdata
{
//	wsprintf(temp1,"MONITOR:ELSE read:Howmany=%d sofar=%d",HowManyCharsWait,HowManyReadSoFar);
	nLength=AGWPESocket->Receive(TempRead,500);
	if (nLength== SOCKET_ERROR)  return ;
	if (HowManyReadSoFar)
      MoveMemory(ReadedData,ReadedData+HowManyReadSoFar,HowManyCharsWait-HowManyReadSoFar);

	MoveMemory(ReadedData+(HowManyCharsWait-HowManyReadSoFar),TempRead,nLength);

//   wsprintf(temp1,"MONITOR:ELSE read:Howmany=%d sofar=%d readnow=%d =%d",HowManyCharsWait,HowManyReadSoFar,nLength,Header.size);	OutputDebugString(temp1);

	HowManyCharsWait-=HowManyReadSoFar;
	HowManyCharsWait+=nLength;
	HowManyReadSoFar=0;
	ReadedDataPtr=ReadedData;
}
//wsprintf(temp1,"MONITOR::READ %d",HowManyCharsWait);OutputDebugString(temp1);
if (!HowManyCharsWait) return;

for (;;)
{
if ((flag==NOMORE2READ)|| (flag==MORE2READHEAD))
{
	if ((HowManyCharsWait-HowManyReadSoFar)<=0) {flag=NOMORE2READ;return;}//we read all the data
   if ((HowManyCharsWait-HowManyReadSoFar)<sizeof(Header)) {flag=MORE2READHEAD;return;}//we read all the data
   HowManyReadSoFar+=sizeof(Header);
   MoveMemory(&Header,ReadedDataPtr,sizeof(Header));
  // wsprintf(temp1,"MONITOR::Header.size=%d",Header.size);OutputDebugString(temp1);
   ReadedDataPtr+=sizeof(Header);
   if (Header.port>=250) Header.port=0;
}
	switch((LOWORD(Header.DataKind)))
	{
	case 'U'://MONITOR DATA UNPROTO
         if ((HowManyCharsWait-HowManyReadSoFar)<Header.size) {flag=MORE2READ;return;}
		  MoveMemory(szData,ReadedDataPtr,Header.size);
          HowManyReadSoFar+=Header.size;
          ReadedDataPtr+=Header.size;
	       if ((MonitorKind & MU)==MU)
          {
			  if (OEMANSI) 	OemToChar((char *)szData,(char *)szData);

			 Term[Header.port]->InsertTerm(szData,Header.size);
			 }
          flag=NOMORE2READ;
			 continue;

	case 'T'://TXDATA MONITOR DIKA MAS
         if ((HowManyCharsWait-HowManyReadSoFar)<Header.size) {flag=MORE2READ;return;}
		  MoveMemory(szData,ReadedDataPtr,Header.size);
          HowManyReadSoFar+=Header.size;
          ReadedDataPtr+=Header.size;
			 if ((MonitorKind & MTX)==MTX)
			  if (OEMANSI) 	OemToChar((char *)szData,(char *)szData);

			 Term[Header.port]->InsertTerm(szData,Header.size);
          flag=NOMORE2READ;
			 continue;
	case 'S'://MONITOR HEADER
         if ((HowManyCharsWait-HowManyReadSoFar)<Header.size) {flag=MORE2READ;return;}
		  MoveMemory(szData,ReadedDataPtr,Header.size);
          HowManyReadSoFar+=Header.size;
          ReadedDataPtr+=Header.size;

			 if ((MonitorKind & MS)==MS)
			  if (OEMANSI) 	OemToChar((char *)szData,(char *)szData);

			Term[Header.port]->InsertTerm(szData,Header.size);
          flag=NOMORE2READ;
			 continue;
	case 'I'://MONITOR  HEADER+DATA CONNECT OTHER STATIONS
         if ((HowManyCharsWait-HowManyReadSoFar)<Header.size) {flag=MORE2READ;return;}
		  MoveMemory(szData,ReadedDataPtr,Header.size);
          HowManyReadSoFar+=Header.size;
          ReadedDataPtr+=Header.size;

			 if ((MonitorKind & MI)==MI)
			  if (OEMANSI) 	OemToChar((char *)szData,(char *)szData);

			Term[Header.port]->InsertTerm(szData,Header.size);
          flag=NOMORE2READ;
			 continue;
	case 'H'://MHeardList
         if ((HowManyCharsWait-HowManyReadSoFar)<Header.size) {flag=MORE2READ;return;}
		  MoveMemory(szData,ReadedDataPtr,Header.size);
          HowManyReadSoFar+=Header.size;
          ReadedDataPtr+=Header.size;
          if (Header.callfrom[0]==' ')  continue;
//	       if (szData[0]==' ') break;//no more mheard less than 20stations
	      wsprintf(HeardListStr,"Port%d>%s\r",Header.port+1,szData);
			Term[Header.port]->InsertTerm((unsigned char*)HeardListStr,lstrlen(HeardListStr)+1);
          flag=NOMORE2READ;
		  continue;
   case 'G'://PORT LIST
//          OutputDebugString("MONITOR G RCV");
         if ((HowManyCharsWait-HowManyReadSoFar)<Header.size) {flag=MORE2READ;return;}
//         wsprintf(temp1,"Monitor:G header size=%d",Header.size);OutputDebugString(temp1);
		  MoveMemory(szData,ReadedDataPtr,Header.size);
          HowManyReadSoFar+=Header.size;
          ReadedDataPtr+=Header.size;
            GetPorts(szData);
//        		if (Term[0]==NULL) StartAfterConnect();
       struct HEADER Hed;
	    Hed.port=0;
   	 Hed.DataKind=MAKELONG('m',0);
    	 lstrcpy((char *)Hed.callfrom,"TEST");
    	 lstrcpy((char *)Hed.callto,"TEST");
    	 Hed.size=0;
		 AGWPESocket->Send(&Hed,sizeof(Hed));

          flag=NOMORE2READ;

             continue;

	default:
         if ((HowManyCharsWait-HowManyReadSoFar)<Header.size) {flag=MORE2READ;return;}
		  MoveMemory(szData,ReadedDataPtr,Header.size);
          HowManyReadSoFar+=Header.size;
          ReadedDataPtr+=Header.size;
			  if (OEMANSI) 	OemToChar((char *)szData,(char *)szData);

	       Term[0]->InsertTerm(szData,Header.size);
          wsprintf((char *)szData,"%d=%c",Header.port,Header.DataKind);
//	       Term[0]->InsertTerm(szData,lstrlen(szData));
          flag=NOMORE2READ;
        }//END SWITCH
 }//end for readdata


}
//*****************************************

/*void CMainFrame::ReceiveData(void)
{
DWORD HowManyCharsWait;
DWORD HowManyReadSoFar=0;
UINT  nLength;
char HeardListStr[100];

static char flag=NOMORE2READ;
static HEADER Header;
unsigned char szData[3001];
//HowManyCharsWait=SockFile->Read(DataRead,3000);
//HowManyCharsWait=SockFile->GetLength();
//TRACE1("GETLENGTH=%d",HowManyCharsWait);
if (!AGWPESocket->IOCtl(FIONREAD,&HowManyCharsWait)) return;

for (;;)
{

if ((flag==NOMORE2READ)||(flag==MORE2READHEAD))
{
 if ((HowManyCharsWait-HowManyReadSoFar)<=0) {flag=NOMORE2READ;return;}//we read all the data
 if ((HowManyCharsWait-HowManyReadSoFar)<sizeof(Header)) {flag=MORE2READHEAD;return;}//we read all the data
 nLength=sizeof(Header);//sizeof header
 if (!AGWPESocket->Receive(&Header,sizeof(Header))) return;

 HowManyReadSoFar+=nLength;
 if (Header.port>=250) Header.port=0;
}
	switch((LOWORD(Header.DataKind)))
	{
	case 'U'://MONITOR DATA UNPROTO
		if ((HowManyCharsWait-HowManyReadSoFar)<Header.size) {flag=MORE2READ;return;}
			 if (!AGWPESocket->Receive(szData, Header.size)) return;//read the rest
          HowManyReadSoFar+=Header.size;
	     if ((MonitorKind & MU)==MU)
          {
		    if (OEMANSI) 	OemToChar((char *)szData,(char *)szData);
			 Term[Header.port]->InsertTerm(szData,Header.size);
		 }
		 flag=NOMORE2READ;
			 break;

	case 'T'://TXDATA MONITOR DIKA MAS
     if ((HowManyCharsWait-HowManyReadSoFar)<Header.size) {flag=MORE2READ;return;}
			 if (!AGWPESocket->Receive(szData, Header.size)) return;//read the rest
          HowManyReadSoFar+=Header.size;
		 if ((MonitorKind & MTX)==MTX)
		 {
		  if (OEMANSI) 	OemToChar((char *)szData,(char *)szData);
			 Term[Header.port]->InsertTerm(szData,Header.size);
		 }
		 flag=NOMORE2READ;
			 break;
	case 'S'://MONITOR HEADER
     if ((HowManyCharsWait-HowManyReadSoFar)<Header.size) {flag=MORE2READ;return;}
			 if (!AGWPESocket->Receive(szData, Header.size)) return;//read the rest
          HowManyReadSoFar+=Header.size;
		 if ((MonitorKind & MS)==MS)
		 {
		   if (OEMANSI) 	OemToChar((char *)szData,(char *)szData);
			Term[Header.port]->InsertTerm(szData,Header.size);
         }
		 flag=NOMORE2READ;
			 break;
	case 'I'://MONITOR  HEADER+DATA CONNECT OTHER STATIONS
     if ((HowManyCharsWait-HowManyReadSoFar)<Header.size) {flag=MORE2READ;return;}
			 if (!AGWPESocket->Receive(szData, Header.size)) return;//read the rest
          HowManyReadSoFar+=Header.size;
		 if ((MonitorKind & MI)==MI)
		 {
			if (OEMANSI) 	OemToChar((char *)szData,(char *)szData);
			Term[Header.port]->InsertTerm(szData,Header.size);
		 }
		 flag=NOMORE2READ;
			 break;
	case 'H'://MHeardList
     if ((HowManyCharsWait-HowManyReadSoFar)<Header.size) {flag=MORE2READ;return;}
			 if (!AGWPESocket->Receive(szData, Header.size)) return;//read the rest
          HowManyReadSoFar+=Header.size;
          if (Header.callfrom[0]==' ') break;
	      wsprintf(HeardListStr,"Port%d>%s\r",Header.port+1,szData);
//			Term[Header.port]->InsertTerm(HeardListStr,lstrlen(HeardListStr)+1);
		 flag=NOMORE2READ;
		 break;
   case 'G'://PORT LIST
     if ((HowManyCharsWait-HowManyReadSoFar)<Header.size) {flag=MORE2READ;return;}
			 if (!AGWPESocket->Receive(szData, Header.size)) return;//read the rest
          HowManyReadSoFar+=Header.size;
          OutputDebugString("MONITOR G RCV\n");
            GetPorts(szData);
//        		if (Term[0]==NULL) StartAfterConnect();
       struct HEADER Hed;
	     Hed.port=0;
   	     Hed.DataKind=MAKELONG('m',0);
    	 lstrcpy((char *)Hed.callfrom,"TEST");
    	 lstrcpy((char *)Hed.callto,"TEST");
    	 Hed.size=0;
		 AGWPESocket->Send(&Hed,sizeof(Hed));

OutputDebugString("RETURN G\n");
		 flag=NOMORE2READ;
            break;

	default:
     if ((HowManyCharsWait-HowManyReadSoFar)<Header.size) {flag=MORE2READ;return;}
			 if (!AGWPESocket->Receive(szData, Header.size)) return;//read the rest
          HowManyReadSoFar+=Header.size;
		 flag=NOMORE2READ;
		 //through away
//		 if (OEMANSI) 	OemToChar((char *)szData,(char *)szData);
//	       Term[0]->InsertTerm(szData,Header.size);
//         wsprintf((char *)szData,"%d=%c",Header.port,Header.DataKind);
//	       Term[0]->InsertTerm(szData,lstrlen(szData));

        }//END SWITCH
 }//end for readdata

}*/
//*****************************************

void CMainFrame::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
TRACE0("MAINFRM::ONCLOSE1\n");
TRACE0("MAINFRM::ONCLOSE2\n");
AGWPESocket->Close();	
TRACE0("MAINFRM::ONCLOSE3\n");
for (int x=0;x<Ports.Num;x++) Term[x]->SendMessage(WM_CLOSE,0,0);
//for (int x=0;x<Ports.Num;x++) delete (Term[x]);
	CMDIFrameWnd::OnClose();
}

