// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__722F2C09_375C_11D4_81AD_A6AC0D2E4686__INCLUDED_)
#define AFX_MAINFRM_H__722F2C09_375C_11D4_81AD_A6AC0D2E4686__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "agwsocket.h"
#include "childfrm.h"


class AGWSocket;
struct HEADER
{
int port;
long DataKind;
unsigned char callfrom[10];
unsigned char callto[10];
UINT size;
long User;//reserved
};
//*****************************************************
struct PORTS
{
int Num;
char Port[100][180];
};
//*****************************************************
#define MM 0
#define MI 2
#define MU 4
#define MS 8
#define MC 16
#define MTX 32
#define MRJ 64
#define MVIA 1
//**********************************************************************************************

class CMainFrame : public CMDIFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
	void ReceiveData(void);

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
	CReBar      m_wndReBar;
	CDialogBar      m_wndDlgBar;

// Generated message map functions
private:
	CMenu cm;

//	CSocketFile *SockFile;
	AGWSocket *AGWPESocket;
    void GetPorts(unsigned char *Str);
    struct PORTS Ports;
    int MonitorKind;
	bool OEMANSI;
	CChildFrame *Term[200];
	void CreateTerms(void);
char ReadedData[3000];
int HowManyCharsWait;
int HowManyReadSoFar;
unsigned char szData[3001];

protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__722F2C09_375C_11D4_81AD_A6AC0D2E4686__INCLUDED_)
