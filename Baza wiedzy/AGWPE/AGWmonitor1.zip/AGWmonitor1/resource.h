//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AGWmonitor.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_AGWMONTYPE                  129
#define IDD_DIALOG1                     131
#define IDD_DIALOG2                     132
#define IDC_FONTCOMBO                   1003
#define IDC_FONTSIZECOMBO               1004
#define IDC_CHECK1                      1005
#define IDC_CHECK2                      1006
#define IDC_CHECK3                      1007
#define IDC_CHECK4                      1008
#define IDC_CHECK6                      1010
#define IDC_BUTTON1                     1011
#define IDC_BUTTON2                     1012
#define IDC_EDIT1                       1013
#define ID_PROPERTIES                   32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
