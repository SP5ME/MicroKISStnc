// ChildFrm.cpp : implementation of the CChildFrame class
//

#include "stdafx.h"
#include "AGWmonitor.h"

#include "ChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern char IniFile[];
char s10[]={10,0};
extern	HMENU m_hMDIMenu;

/////////////////////////////////////////////////////////////////////////////
// CChildFrame

IMPLEMENT_DYNCREATE(CChildFrame, CMDIChildWnd)

BEGIN_MESSAGE_MAP(CChildFrame, CMDIChildWnd)
	//{{AFX_MSG_MAP(CChildFrame)
		ON_WM_SETFOCUS()
		ON_WM_CREATE()
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildFrame construction/destruction

CChildFrame::CChildFrame()
{
	// TODO: add member initialization code here
	
}

CChildFrame::~CChildFrame()
{
	OutputDebugString("~CHILDFRAME\n");
}

BOOL CChildFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.hMenu=m_hMDIMenu;
//	cs.lpszClass = AfxRegisterWndClass(0);

	if( !CMDIChildWnd::PreCreateWindow(cs) )
		return FALSE;


	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CChildFrame diagnostics

#ifdef _DEBUG
void CChildFrame::AssertValid() const
{
	CMDIChildWnd::AssertValid();
}

void CChildFrame::Dump(CDumpContext& dc) const
{
	CMDIChildWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CChildFrame message handlers
/*void CChildFrame::OnFileClose() 
{
	// To close the frame, just send a WM_CLOSE, which is the equivalent
	// choosing close from the system menu.
OutputDebugString("CHILDFRAM ONFILECLOSE\n");
	SendMessage(WM_CLOSE);
}
*/
int CChildFrame::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CMDIChildWnd::OnCreate(lpCreateStruct) == -1)
		return -1;


	// create a view to occupy the client area of the frame
//	m_wndView.m_nWordWrap =CRichEditView::WrapNone;
//	if (!m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW, 
//		CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL))
	if (!m_wndView.Create(ES_AUTOHSCROLL |ES_AUTOVSCROLL |ES_MULTILINE |WS_CHILD |  WS_VISIBLE  |WS_VSCROLL  | WS_HSCROLL       , 
		CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST))
	{
		TRACE0("Failed to create view window\n");
		return -1;
	}
    //m_wndView.WrapChanged();
m_wndView.SetDefaultCharFormat(cf);
	return 0;
}
//*********************************************************************************
void CChildFrame::OnSetFocus(CWnd* pOldWnd) 
{
	CMDIChildWnd::OnSetFocus(pOldWnd);

	m_wndView.SetFocus();
}
//*********************************************************************************
/*BOOL CChildFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo) 
{
//	TRACE0("ONCMDMSG\n");
	// let the view have first crack at the command
//	if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))		return TRUE;
	
	// otherwise, do default handling
	return CMDIChildWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}
*/
//**********************************************************************************
void CChildFrame::InsertTerm(unsigned char *Data,int Datalen)
{
//OutputDebugString("INSERT TERM\n");
char *token;
int x=0;
int lines,oldsize,counter;
unsigned char st[3001],sth[2700];
CHARRANGE selection;

//TRACE1("DATALEn=%d\n",Datalen);
if (Datalen>3000) return;
if (Datalen<10) return;
//if (!Data) return;
MoveMemory(st,Data,Datalen);
st[Datalen]=NULL;
counter=Change(st);
if (!counter) {TRACE1("!counter=%s\n",Data);return;}

m_wndView.SetReadOnly(FALSE);
lines=m_wndView.GetLineCount();

	if (lines>BufLines) 
	{
//		OutputDebugString("Lines>buflines\n");
	selection.cpMin=0;
    selection.cpMax=counter;
    m_wndView.SendMessage(EM_HIDESELECTION,1,0);
    m_wndView.SendMessage(EM_EXSETSEL,0,(LPARAM)(CHARRANGE FAR *)&selection);
    m_wndView.SendMessage(WM_CLEAR);
    //m_wndView.SendMessage(EM_REPLACESEL,FALSE,NULL);
	}
	oldsize=m_wndView.GetTextLength();
	selection.cpMin=oldsize;
	selection.cpMax=oldsize;
	m_wndView.SendMessage(EM_EXSETSEL,0,(LPARAM)(CHARRANGE FAR *)&selection);

token=strtok((char *)st,s10);
if  (token) 
{
	lstrcpy((char *)sth,token);
	x=lstrlen(token);
	sth[x]=10;x++;sth[x]=NULL;
} else 
{
	lstrcpy((char *)sth,(char *)st);
	x=lstrlen((char *)sth);
	sth[x]=10;x++;sth[x]=NULL;

}
PutIn(sth);//header
oldsize=m_wndView.GetTextLength();
selection.cpMin=oldsize;
selection.cpMax=oldsize;
m_wndView.SendMessage(EM_EXSETSEL,0,(LPARAM)&selection);
//if (x<=counter) if (st[0]==10) PutIn(st+x+1); else {OutputDebugString("just header\n");PutIn(st+x);}//rest of frame
//TRACE2("DATALEnx=%d=%d\n",x,counter);

if (x<=counter) PutIn(st+x);
//goto end of text

oldsize=m_wndView.GetTextLength();
selection.cpMin=oldsize;
selection.cpMax=oldsize;
m_wndView.SendMessage(EM_EXSETSEL,0,(LPARAM)(CHARRANGE FAR *)&selection);
m_wndView.SendMessage(EM_SCROLLCARET,0,0);
m_wndView.SetReadOnly(TRUE);
//OutputDebugString("EXIT TERM\n");
}
//*********************************************************************************
int CChildFrame::Change(unsigned char *str)
{
int y=lstrlen((char *)str);
for (int x=0;x<y;x++)
{
if ((str[x]==13) && (str[x+1]==10))//change 1310 to 10
      {
      str[x]=10;
      x++;
      y--;//del one char
      for (int z=x;z<y;z++) str[z]=str[z+1];
      }
else if ((str[x]==10) && (str[x+1]==13))//change 1013 to 10
      {
      x++;
      y--;//del one char
      for (int z=x;z<y;z++) str[z]=str[z+1];
      }
else if (str[x]==13) str[x]=10;
}//end for
str[y]=NULL;
return y;
}
//*************************************************************************************
void CChildFrame::PutIn(unsigned char *s)
{
//m_wndView.GetRichEditCtrl().GetSelectionCharFormat(cf);
m_wndView.GetSelectionCharFormat(cf);
cf.dwMask|=CFM_COLOR;
cf.dwEffects=0;
COLORREF oldcolor=cf.crTextColor;
if (s[3]=='F' && s[4]=='m')
       {
       if (SearchStr) if (strstr((char *)s,SearchStr)) cf.crTextColor=ColorMine;
       else     cf.crTextColor=ColorHeader;

       }
   else if (s[0]==':' && s[1]=='>') cf.crTextColor=ColorMine;//gia ayta poy grafoyme emeis
  else cf.crTextColor=ColorInfo;
if (oldcolor!=cf.crTextColor) m_wndView.SetSelectionCharFormat(cf);
m_wndView.SendMessage(EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)s);
//Insert(s);
}
//***********************************************************************************
void CChildFrame::Setup(COLORREF HeaderColor1,COLORREF WinColor1,COLORREF MyColor1,char * SearchStr1)
{
lstrcpy(SearchStr,SearchStr1);
ColorMine=MyColor1;
ColorHeader=HeaderColor1;
ColorInfo=WinColor1;
BufLines=500;
 //load fonts
 //*****************************************
//CHARFORMAT cf;
ZeroMemory(&cf,sizeof(cf));
cf.cbSize=sizeof(cf);
cf.dwEffects=0;
cf.dwMask=0;

cf.dwMask=CFM_FACE|CFM_CHARSET|CFM_SIZE;
cf.dwEffects=0;
if (GetPrivateProfileInt("FONTS","ITALIC",0,IniFile)) 
{
	cf.dwMask|=CFM_ITALIC;
	cf.dwEffects=CFE_ITALIC;
}
if (GetPrivateProfileInt("FONTS","UNDERLINE",0,IniFile))
{
	cf.dwMask|=CFM_UNDERLINE;
	cf.dwEffects|=CFE_UNDERLINE;
}
if (GetPrivateProfileInt("FONTS","STRIKEOUT",0,IniFile))
{
	cf.dwMask|=CFM_STRIKEOUT;
	cf.dwEffects|=CFE_STRIKEOUT;
}
if (GetPrivateProfileInt("FONTS","BOLD",0,IniFile))
{
	cf.dwMask|=CFM_BOLD;
	cf.dwEffects|=CFE_BOLD;
}
cf.yHeight=GetPrivateProfileInt("FONTS","HEIGHT",0,IniFile);
//cf.yOffset=GetPrivateProfileInt("FONTS","WIDTH",0,IniFile);
cf.bCharSet=GetPrivateProfileInt("FONTS","SET",161,IniFile);
GetPrivateProfileString("FONTS","NAME","Fixedsys",cf.szFaceName, LF_FACESIZE-1,IniFile);
//m_wndView.SetCharFormat(cf);

}
//***********************************************************************************


void CChildFrame::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	TRACE0("CHILDFRAME::ONCLOSE\n");
//	m_wndView.DestroyWindow();
	CMDIChildWnd::OnClose();
}
