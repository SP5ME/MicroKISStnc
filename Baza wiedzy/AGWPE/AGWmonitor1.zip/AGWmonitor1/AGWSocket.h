#if !defined(AFX_AGWSOCKET_H__47E350E4_366A_11D4_81AD_A6AC0D2E4686__INCLUDED_)
#define AFX_AGWSOCKET_H__47E350E4_366A_11D4_81AD_A6AC0D2E4686__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AGWSocket.h : header file
//
#include "Mainfrm.h"
class CMainFrame;

/////////////////////////////////////////////////////////////////////////////
// AGWSocket command target

class AGWSocket : public CSocket
{
// Attributes
public:

// Operations
public:
	AGWSocket();
	virtual ~AGWSocket();
	void SetDsktp(CMainFrame *Dsktp);
// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(AGWSocket)
	public:
	virtual void OnReceive(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(AGWSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

private:
CMainFrame *AgwDsktp;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AGWSOCKET_H__47E350E4_366A_11D4_81AD_A6AC0D2E4686__INCLUDED_)
