// AGWSocket.cpp : implementation file
//

#include "stdafx.h"
#include "agwmonitor.h"
#include "AGWSocket.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// AGWSocket

AGWSocket::AGWSocket()
{
	AgwDsktp=NULL;
}

AGWSocket::~AGWSocket()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(AGWSocket, CSocket)
	//{{AFX_MSG_MAP(AGWSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// AGWSocket member functions

void AGWSocket::OnReceive(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	if (AgwDsktp) AgwDsktp->ReceiveData();
	CSocket::OnReceive(nErrorCode);
}
//**************************************************************************************
void AGWSocket::SetDsktp(CMainFrame *Dsktp)
{
	AgwDsktp=Dsktp;
}
//**************************************************************************************
