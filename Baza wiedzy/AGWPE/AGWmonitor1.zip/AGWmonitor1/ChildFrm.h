// ChildFrm.h : interface of the CChildFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHILDFRM_H__722F2C0B_375C_11D4_81AD_A6AC0D2E4686__INCLUDED_)
#define AFX_CHILDFRM_H__722F2C0B_375C_11D4_81AD_A6AC0D2E4686__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include <richedit.h>
#include <afxrich.h>

class CChildFrame : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CChildFrame)
public:
	CChildFrame();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChildFrame)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	// view for the client area of the frame.
//	CChildView m_wndView;
//	CRichEditView m_wndView;
	CRichEditCtrl m_wndView;
	virtual ~CChildFrame();
    void InsertTerm(unsigned char *Data,int Datalen);
	void Setup(COLORREF HeaderColor1,COLORREF WinColor1,COLORREF MyColor1,char * SearchStr1);
private:
	int Change(unsigned char *str);
	int BufLines;
    void PutIn(unsigned char *s);
    char SearchStr[300];
COLORREF ColorHeader,ColorInfo,ColorMine;
CHARFORMAT cf;

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

// Generated message map functions
protected:
	//{{AFX_MSG(CChildFrame)
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHILDFRM_H__722F2C0B_375C_11D4_81AD_A6AC0D2E4686__INCLUDED_)
