#ifndef __STRUCT_H
#define __STRUCT_H
struct PORTS
{
int Num;
char Port[20][80];
};
//////////////////////
struct HEADERTCP
{
int port;
long DataKind;
unsigned char callfrom[10];
unsigned char callto[10];
int size;
long User;//reserved
};
//********
struct _OUTPUT_REQUEST {
    WSABUF          Buffer;     // holds the buffer (pointer) and size
    LPWSAOVERLAPPED Overlapped; // NULL if not an overlapped send
//    SOCKWIN *SockWinThis;
};
class stframe
{
public:
     stframe(int Size);
     ~stframe();
    struct stframe *next;
    int size;
    int frmlen;
    unsigned char *data;
    void add_frm(unsigned char *p,int n);
};


struct stqcell {struct stqcell *next;};

class simplequeue
{
    public:
    simplequeue(void);
    bool IsData();
    void *getq(void);
    void *getCheckq(void);
    void putq(struct stqcell *d);
    int cntq(void);
    struct stqcell *head;
    struct stqcell *tail;
    struct stqcell *r;
    ~simplequeue();


};


#endif