#if !defined _AGWMONITOR_H
#define _AGWMONITOR_H

#include <windows.h>



LRESULT CALLBACK MainWndProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK AGWTerminalWinProc(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK ChildWinProc(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam);


#endif

