#if !defined _CONSTANT_H
#define _CONSTANT_H


#define INITIALIZE 500

#define CM_PROPERTIES                   108
#define CM_FILEPRINT                    109
#define CM_MHEARD                       110
#define CM_VIEWTOOLBAR                  111
#define CM_VIEWSTATUSBAR                112
#define CM_ABOUT                        113

#define CM_CASCADECHILDREN          1200
#define CM_TILECHILDREN             1201
#define CM_TILECHILDRENHORIZ        1202
#define CM_ARRANGEICONS             1203
#define IDM_WINDOWCHILD                 1210


/*#define IDM_WINDOWTILE                  1200
#define IDM_WINDOWCASCADE               1201
#define IDM_WINDOWCLOSEALL              1202
#define IDM_WINDOWICONS                 1203
#define IDM_WINDOWCHILD                 1210
  */
#define IDM_EXIT                        4002
#define IDM_HELP                        4003



/*#define ICON_1 100
#define MENU_1	        100
#define IDM_ACTIONMENU 101
  */

#define MM 0
#define MI 2
#define MU 4
#define MS 8
#define MC 16
#define MTX 32
#define MRJ 64
#define MVIA 1


#endif
