//
//@ SV2AGW 2000.....
#if !defined _AGWTERMINALCANVAS_H
#define _AGWTERMINALCANVAS_H
#include <winsock2.h>
#include <windows.h>

//
// cursor states
//
#define CS_HIDE         0x00
#define CS_SHOW         0x01
#define ASCII_LF        0x0A
#define ASCII_CR        0x0D

class AGWTerminalCanvas
{
public:
      AGWTerminalCanvas(int Rows,int Cols);
		BOOL ScrollTTYVert(HWND hWnd,WORD wScrollCmd, WORD wScrollPos );
		BOOL ScrollTTYHorz(HWND hWnd, WORD wScrollCmd, WORD wScrollPos );
		BOOL PaintTTY( HWND hWnd );
		BOOL MoveTTYCursor( );
		BOOL SetTTYFocus( HWND hWnd );
		BOOL KillTTYFocus( HWND hWnd );
		BOOL SizeTTY( HWND hWnd, WORD wWidth, WORD wHeight );
      void InsertData(HWND Hwnd,LPSTR Data,int DataLen);

private:
    char    *Screen;
    int     MAXROWS;
    int     MAXCOLS;
    HFONT   hTTYFont ;
    LOGFONT lfTTYFont ;
    DWORD   rgbFGColor ;
    int     xSize;
    int     ySize;
    int     xScroll;
    int     yScroll;
    int     xOffset;
    int     yOffset;
    int     nColumn;
    int     nRow   ;
    int     xChar  ;
    int     yChar  ;
    int     nCharPos;
    bool    fAutowrap;
    bool    fNewLine;
    WORD    wCursorState ;
    HWND    _hwnd;
    void InitNewFont(LOGFONT LogFont, COLORREF rgbColor);

};

#endif
