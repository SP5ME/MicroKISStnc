#if !defined ACTIVE_H
#define ACTIVE_H
//------------------------------------
//  active.h
//  Active object framework
//  (c) Bartosz Milewski, 1996
//------------------------------------

#include "thread.h"
#include <windows.h>

class ActiveObject
{
public:
    ActiveObject ();
    virtual ~ActiveObject () {}
    void Kill ();
    void Resume () { _thread.Resume (); }

protected:
    virtual void InitThread () = 0;
    virtual void Loop () = 0;
    virtual void FlushThread () = 0;

    int             _isDying;

    static DWORD WINAPI ThreadEntry (void *pArg);
    Thread          _thread;
};




#endif