//monitorsocket.h
//@sv2agw 2000
//
#if !defined _MONITORSOCKET_H
#define _MONITORSOCKET_H
#include <winsock2.h>
#include <windows.h>
#include "active.h"
#include "monitordsktp.h"
#include "struct.h"

class MonitorDsktp;

class MonitorSocket:public ActiveObject
{
public:
       MonitorSocket(MonitorDsktp *AParent);
       ~MonitorSocket();
       void Start(void);

private:
    MonitorDsktp *Parent;
    struct PORTS Ports;
    BOOL OEMANSI;
    int MonitorKind;
    int MultiMonitor;
    char MyCall[10];
	 char Section[10];
SOCKET AGWPESocket;
WSAEVENT SockEvent;
WSAEVENT        EventArray[WSA_MAXIMUM_WAIT_EVENTS];
struct _OUTPUT_REQUEST *OutReqArray[WSA_MAXIMUM_WAIT_EVENTS];
int NumEvents;
simplequeue TxQueue;
bool flag;
struct HEADERTCP Header;
BOOL FlagCreateTermWin;
//*****
void GoToIdleState(void);
void GoToIdleStateOut(void);
void PutDataTxQue(unsigned char *szDataToSend, int nCharsToSend);
void ReceivedData(void);
void GetPorts(char *Str);
void WriteEventOccured(DWORD WaitStatus);
void StartAfterConnect(void);
Mutex       _mutex;

void InitThread () {};
void Loop ();
void FlushThread ();

} ;

#endif

