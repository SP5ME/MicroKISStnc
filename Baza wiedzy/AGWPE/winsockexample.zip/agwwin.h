//
#if !defined _AGWWIN_H
#define _AGWWIN_H
//------------------------------------
//  MDI Interface
//  (c) SV2AGW
//------------------------------------
#include <winsock2.h>
#include <windows.h>
#define IDM_WINDOWTILE                  1200
#define IDM_WINDOWCASCADE               1201
#define IDM_WINDOWCLOSEALL              1202
#define IDM_WINDOWICONS                 1203
#define IDM_WINDOWCHILD                 1210
#define  WINDOWMENU                     2
#define MAX_RESSTRING  255 

//
//WINDOW Class
//
class AGWWinClass
{
public:
     AGWWinClass (char const * className, HINSTANCE hInst, WNDPROC wndProc);
     AGWWinClass (int resId, HINSTANCE hInst, WNDPROC wndProc);
    void SetResIcons (int resId);
    void SetResIcons (LPSTR IconName);
    void Register (void);
	 char const * GetName (void) const { return _name; }
	 HINSTANCE GetInstance (void) const { return _hInstance; }
    HWND GetRunningWindow (void);

protected:
	void SetDefaults ();
	HINSTANCE	_hInstance;
	char	_name[MAX_RESSTRING + 5];
    HWND         _hwnd;
	WNDCLASSEX  _class;
};

class AGWFrameWinClass: public AGWWinClass
{
public:
    AGWFrameWinClass (int resId, HINSTANCE hInst, WNDPROC wndProc);
    AGWFrameWinClass (LPSTR aName, HINSTANCE hInst, WNDPROC wndProc);
};


class AGWMDIClass: public AGWWinClass
{
public:
    AGWMDIClass (int resId, HINSTANCE hInst, WNDPROC wndProc);
    AGWMDIClass (LPSTR aName, HINSTANCE hInst, WNDPROC wndProc);
};


class AGWChildClass: public AGWWinClass
{
public:
    AGWChildClass (int resId, HINSTANCE hInst, WNDPROC wndProc);
    AGWChildClass (LPSTR aName, HINSTANCE hInst, WNDPROC wndProc);
};




class AGWFrameWindow
{
public:
    AGWFrameWindow (AGWFrameWinClass & winClass, char const * caption);
    operator HWND () { return _hwnd; }
    void AddCaption (char const * caption)
    {
        _windowName = caption;
    }
    void AddSysMenu ()    { _style |= WS_SYSMENU; }
    void AddVScrollBar () { _style |= WS_VSCROLL; }
    void AddHScrollBar () { _style |= WS_HSCROLL; }
    void Create ();
    void Show (int nCmdShow = SW_SHOWNORMAL);
protected:
	AGWFrameWinClass &	 _class;
    HWND         _hwnd;

    DWORD        _exStyle;       // extended window style
    char const * _windowName;    // pointer to window name
    DWORD        _style;         // window style
    int          _x;             // horizontal position of window
    int          _y;             // vertical position of window
    int          _width;         // window width
    int          _height;        // window height
    HWND         _hWndParent;    // handle to parent or owner window
    HMENU        _hMenu;         // handle to menu, or child-window identifier
    void       * _data;          // pointer to window-creation data
};

class AGWMDI
{
public:
    AGWMDI (AGWMDIClass & winClass, char const * caption);
    operator HWND () { return _hwnd; }
    void AddCaption (char const * caption)
    {
        _windowName = caption;
    }
    void AddSysMenu ()    { _style |= WS_SYSMENU; }
    void AddVScrollBar () { _style |= WS_VSCROLL; }
    void AddHScrollBar () { _style |= WS_HSCROLL; }
    void Create ();
    void Show (int nCmdShow = SW_SHOWNORMAL);
protected:
	AGWMDIClass &	 _class;
    HWND         _hwnd;

    DWORD        _exStyle;       // extended window style
    char const * _windowName;    // pointer to window name
    DWORD        _style;         // window style
    int          _x;             // horizontal position of window
    int          _y;             // vertical position of window
    int          _width;         // window width
    int          _height;        // window height
    HWND         _hWndParent;    // handle to parent or owner window
    HMENU        _hMenu;         // handle to menu, or child-window identifier
    void       * _data;          // pointer to window-creation data
};


/*class AGWMDIClient
{
public:
    AGWMDIClient ( char const * caption,HINSTANCE Hinst);
    operator HWND () { return _hwnd; }
    void AddCaption (char const * caption)
    {
        _windowName = caption;
    }
    void Create (HWND hwnd);
    void Show (int nCmdShow = SW_SHOWNORMAL);
    HWND GetWindow(void)  {return(_hwnd);}
protected:
    HWND         _hwnd;
   CLIENTCREATESTRUCT ccs;


    DWORD        _exStyle;       // extended window style
    char const * _windowName;    // pointer to window name
    DWORD        _style;         // window style
    int          _x;             // horizontal position of window
    int          _y;             // vertical position of window
    int          _width;         // window width
    int          _height;        // window height
    HWND         _hWndParent;    // handle to parent or owner window
    HMENU        _hMenu;         // handle to menu, or child-window identifier
    void       * _data;          // pointer to window-creation data
    HINSTANCE _hinst;
};
  */
#endif

