//
//@ SV2AGW 2000.....
#if !defined _MONITORDSKTP_H
#define _MONITORDSKTP_H
#include <winsock2.h>
#include <windows.h>
#include "monitorsocket.h"
#include "agwterminalcanvas.h"

class MonitorSocket;

class MonitorDsktp
{
public:
     MonitorDsktp (HWND hwnd,char const * caption,HINSTANCE Hinst);
    ~MonitorDsktp ();
    int    Command (int cmd);
    operator HWND () { return _hwnd; }
    void SetupWindow (HWND hwnd);
    HWND GetWindow() { return _hwnd; }
    AGWTerminalCanvas *Terminal;
private:
	 HWND        _hwnd;
    HINSTANCE _hinst;
    MonitorSocket *MSocket;
};


#endif