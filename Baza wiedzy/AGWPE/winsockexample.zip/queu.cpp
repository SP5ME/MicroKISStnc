///VARIOUS HELPER FUNCTIONS
//QUEUE functions
//@ SV2AGW 2000
#include <winsock2.h>
#include <windows.h>
#include "struct.h"

stframe::~stframe()
{
delete(data);
}
//***************************************************************************
stframe::stframe(int Size)
{
data=new unsigned char[Size+10];
    if (data)
    {
        size = Size+5;
	     frmlen = 0;
    }else OutputDebugString("No DATA STFRAME NEW DATA");
}
//************************************************
void stframe::add_frm(unsigned char *p,int n)
{
    while(n-- > 0)
    {
	if (frmlen > size) PostQuitMessage(0);
        data[frmlen++] = *p++;
    }
}
//************************************************

//************************************************************************
bool simplequeue::IsData()
{
if (head) return true; else return false;
}

//*******************
void *simplequeue::getq(void)
{
    r = head;
    if (r != NULL) head = r->next;
    if (head == NULL)  tail = NULL;
    return(r);
}
//*************

void simplequeue::putq(struct stqcell *d)
{
    if ( d == NULL) 	return;
    d->next = NULL;
    if (head == NULL) head = tail = d;
     else
    		{
      		tail->next = d;
	   		tail = d;
    		}
}

//************************************************
//************************************************
int simplequeue::cntq()
{
    struct stqcell *r;
    int n;

    n = 0;
    r = head;
    while(r)
    {
    r = r->next;
	 n++;
    }
    return(n);
}
//********
void *simplequeue::getCheckq(void)
{
    r = head;
    return(r);
}

simplequeue::simplequeue(void)
{
head =NULL;
tail =NULL;

}
simplequeue::~simplequeue()
{
struct stframe *frame;
while ((frame=(stframe *)getq())!=NULL) delete (frame);
}


//***************************************************************************


