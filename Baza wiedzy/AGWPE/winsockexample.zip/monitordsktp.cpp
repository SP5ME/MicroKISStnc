//
//@ SV2AGW 2000
//
#include <winsock2.h>
#include "monitordsktp.h"
#include "agwterminalcanvas.h"
#include "constant.h"
#include "struct.h"
//*****************************************************************
extern char IniFile[];
//*****************************************************************


MonitorDsktp::MonitorDsktp (HWND hwnd,char const * caption,HINSTANCE Hinst)
{
_hwnd=hwnd;
_hinst=Hinst;

}
//************************************************************

MonitorDsktp::~MonitorDsktp()
{
if (MSocket) delete MSocket;
if (Terminal) delete Terminal;
::PostQuitMessage(0);
}
//************************************************************
void MonitorDsktp::SetupWindow (HWND hwnd)
{
OutputDebugString("MONITORDSKTP->setupwindow");
//create the terminal window painting area (canvas)
Terminal=new AGWTerminalCanvas(100,80);//rows,columns
//create the socket object
MSocket= new MonitorSocket(this);
if (!MSocket) OutputDebugString("MSOCKET CREATE ERROR");
else MSocket->Start();//start the socket thread
}

//************************************************************
// Menu commands processing

int MonitorDsktp::Command (int cmd)
{
    switch (cmd)
    {
    case IDM_EXIT:
        PostQuitMessage(0);
        return(0);
        break;
    case IDM_HELP:
        return(0);
        break;
   case CM_PROPERTIES  :
        OutputDebugString("CM_PROPERTIES");
        return(0);


    }
    return (1);
}


