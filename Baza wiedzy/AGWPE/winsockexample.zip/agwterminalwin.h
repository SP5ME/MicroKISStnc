//
//@ SV2AGW 2000.....
#if !defined _AGWTERMINALWIN_H
#define _AGWTERMINALWIN_H
#include <winsock2.h>
#include <windows.h>

//
// cursor states
//
#define CS_HIDE         0x00
#define CS_SHOW         0x01

class AGWTERMINALWIN
{
public:
      AGWTERMINALWIN(HWND ParentWindow,int Rows,int Cols,LPSTR Atitle);
		BOOL ScrollTTYVert(HWND hWnd,WORD wScrollCmd, WORD wScrollPos );
		BOOL ScrollTTYHorz(HWND hWnd, WORD wScrollCmd, WORD wScrollPos );
		BOOL PaintTTY( HWND hWnd );
		BOOL MoveTTYCursor( HWND hWnd );
		BOOL SetTTYFocus( HWND hWnd );
		BOOL KillTTYFocus( HWND hWnd );
		BOOL SizeTTY( HWND hWnd, WORD wWidth, WORD wHeight );
private:
    char Title[100];
    char    *Screen;
    int     MAXROWS;
    int     MAXCOLS;
    HFONT   hTTYFont ;
    LOGFONT lfTTYFont ;
    DWORD   rgbFGColor ;
    int     xSize;
    int     ySize;
    int     xScroll;
    int     yScroll;
    int     xOffset;
    int     yOffset;
    int     nColumn;
    int     nRow   ;
    int     xChar  ;
    int     yChar  ;
    int     nCharPos;
    bool    fAutowrap;
    bool    fNewLine;
    WORD    wCursorState ;
    HWND    _hwnd,ParentWindow;
void InitNewFont(LOGFONT LogFont, COLORREF rgbColor);

};

#endif
